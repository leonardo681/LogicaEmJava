public class Retangulo implements Desenhavel {
    @Override
    public void desenhar() {
        System.out.println("Desenhando um Retangulo");
    }
}