public class Circulo implements Desenhavel {
    @Override
    public void desenhar() {
        System.out.println("Desenhando um circulo");
    }
}