public interface Desenhavel
{
     void desenhar();
}