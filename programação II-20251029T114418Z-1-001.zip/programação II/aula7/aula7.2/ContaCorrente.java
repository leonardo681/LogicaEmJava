public class ContaCorrente
{
    private double saldo;

    public ContaCorrente(double saldo)
    {
        this.saldo = saldo;
    }

    public void retirada(double valor)
    {
         while(valor>saldo){
                System.out.println("Saldo indisponível");
                valor = Teclado.leDouble("Informe um novo valor para saque" );
        }
        saldo-=valor;
    }
   
    public void deposito(double valor)
    {
         while(valor<=0){
                System.out.println("valor incorreto para deposito");
                valor = Teclado.leDouble("Informe um novo valor para deposito" );
        }
        saldo+=valor;
    }
   
    public void emprestimo(double valor, double parcelas)
    {
        while(parcelas<=0){
                System.out.println("Valor incorreto de Parcelas");
                parcelas = Teclado.leInt("Informe a qtd de Parcelas (1-12)" );
        }
        double valorParcela = valor/parcelas;
        double valorTotalEmprestimo = 0;
        for(int contador = 1; contador <= parcelas; contador++){
            valorParcela += valorParcela*0.05;
            System.out.printf("O valor da parcela %d é: %4.2f \n", contador, valorParcela);
            valorTotalEmprestimo = valorTotalEmprestimo + valorParcela;
           
        }
        saldo+=valor;
        System.out.println("O valor total do Emprestimo é: " + String.format("%4.2f", valorTotalEmprestimo));
    }
   
    public void consultaSaldo(){
        System.out.printf("Seu saldo é: %4.2f \n ", saldo);
    }
    public void opcoes(){
        System.out.println("Bem vindo ao Caixa Eletronico!");
        System.out.println("As opcoes disponiveis são.");
        System.out.println("1-Saque");
        System.out.println("2-Deposito");
        System.out.println("3-emprestimo");
        System.out.println("4-Consulta Saldo");
        System.out.println("0-Encerrar");
    }
}