public class CaixaEletronico
{
    public static void main(String args[]){
        ContaCorrente conta = new ContaCorrente(600.00);
        int opcao;
       
        do{
            conta.opcoes();
            opcao = Teclado.leInt("Informe a opcao desejada: ");
            while(opcao<0 && opcao>4){
                opcao = Teclado.leInt("Opcao Invalida. Informe a opcao desejada: ");
            }
            double valor;
            int parcelas;
           
            switch(opcao){
                case 1:
                    valor = Teclado.leDouble("Informe o valor do Saque): ");
                    conta.retirada(valor);
                    break;
                case 2:
                    valor = Teclado.leDouble("Informe o valor do Deposito): ");
                    conta.deposito(valor);
                    break;
                case 3:
                    valor = Teclado.leDouble("Informe o valor do Emprestimo): ");
                    parcelas = Teclado.leInt("Informe a qtd de Parcelas): ");
                    conta.emprestimo(valor, parcelas);
                    break;
                case 4:
                    conta.consultaSaldo();
                default:
                    System.out.println("Encerrando Sistema");
            }
           
           
           
        }while(opcao!=0);
    }
}